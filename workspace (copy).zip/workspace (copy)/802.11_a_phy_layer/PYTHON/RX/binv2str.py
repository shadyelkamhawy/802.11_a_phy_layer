def binv2str(mac_vector):
    mac_bin_str = ''
    for n in range(0, len(mac_vector)):
        mac_bin_str = mac_bin_str + str(mac_vector[n])

    return mac_bin_str

